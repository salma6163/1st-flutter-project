import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Color(0xff094f62),
        appBar: AppBar(
          title: Text('1st Flutter project'),
          backgroundColor: Color(0xff094f62),
        ),

        //body: Image(
        //  image: NetworkImage(
        //    'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAmVBMVEX///9UxfgBV5sptvZOw/hmyvnd8v265fzY8P2lu9NBwfgATZYAUZjx+v7o9v4AsfUuaqUBU5TM2ObR7P0ARZMBUI4osO4AI0EAK0wBTYkBWJ0BR34BQXQGSHoARoABRHkBOmcEKkUANmA+aJEAP3wsY5kGQ3EFPmgANWIFNVgAL1cELk0AJ0kAHzoApOXM0tkANHoYYKC6y97l99FiAAADQElEQVR4nO3cjXKaUBCGYSNqU1uTmoRTFVS0bYz2v/d/cQXEFA1wfkg5uzvfewHOPrPIgRnHXg8hhBBCCCF9ozdtuvc9vr7r8cC98XDie35t1+Mr9wZD3+PrAxBA4gEIIPEABJB4AAJIPAABJB6AABIPQACJByCAxAMQQOIBCCDxAASQeAACSDwAASQegAASD0AAiQcggMQDEEDiAQgg8QAEkHgAAkg8AAEkHoAAEg9AAIkHIIDEAxBA4gEIIPEABJB4AAJIPAABJB6AABLvvwIno1bRB94Mxm26YQActPjwq1f560vCwIF0oPgNAghg1kQ6sNUOeQBbELkAnYl8gI5EDgd9KyKnDToRuQGtifyAlkSOQCsiT6AFkSvQmMgXaEjkDDQi8jroHYi8N2hA5A/UELXAgD6wkagHBgF9YAPRBOhM7BBYSzQDOhI7BdYQTYFOxI6BlURzoAOxc2AF0QZoTezgoH/ZBVELvA3ciR42mHVGtNugJdET8IxoD7QgegOWiC5AY6JH4DPRDWhI9AosiK5AI6JnYE50BxoQvQMzYguglkgAmBKbZ2gGaoheDnrLLg96KyKJDWrSbbCRKAVYS5QDrCFKAlYSZQEriNKAL4jygBdEicAzooyDvoEoc4MlolxgQZQMzImygSmRA3DUAhgEQ/rA3r3DbfQ59cn3+Ca1IKrl5y++xzfJnbhche8/+B7fJEeiSoHTvmDiEdiXS1TLKAeKJf4DCiWml+h8ehJKJKrHdQkokJgBw7JQGrEAloWyiOoxzoFnQklEtYtXFUI5xBQYzcMKoRSi2iXrebVQBlHtntarOqEEoto/xVF0Egokqv0hWR+F1UvkTlRfD0ncLORNTIHbTLiqv0p5E9XmWwo87bBWyJeoNh8PJeHlUxt/YgqcFcL0Kr147pZAzICZML/TpK+G/UU9kCUxBx6FcRT2m30ciUfgbL/dJtFUp+NILICzQxwuFkZAZsQCmMxNddyIOTCZa797bIlq830b9a3Wx4v4Y5aE9jhOxJ+/woazXQTx7sEZCCKZQAQRRBqBCCKINAIRRBBpBCKIINIIRBCZEN+59/CbwQ/8e3dv2/TH9/gIIYQQQuhV+guw4Ja59nVz8QAAAABJRU5ErkJggg=='),
        // )

        // body: Container(
        //   width: 200,
        //   height: 200,
        //   color: Colors.red,
        //   margin: EdgeInsets.all(0),
        //   padding: EdgeInsets.symmetric(vertical: 50, horizontal: 50),
        //   child: Text("salma"),
        // ),
        //

        // body: Column(
        //     //mainAxisAlignment: MainAxisAlignment.center,
        //     crossAxisAlignment: CrossAxisAlignment.center,
        //     children: [
        //       //children يتكتب فيها اكتر من حاجه
        //       Text("data"),
        //       Text("salma"),
        //     ]),
        // body: Column(children: [
        //   // Text(
        //   //   "data",
        //   //   style: TextStyle(fontSize: 50),
        //   // ),
        //   // Icon(
        //   //   Icons.phone,
        //   //   color: Colors.red,
        //   //   size: 50,
        //   // ),
        //   //
        //   //
        //   //
        //   //
        //   //

        //   CircleAvatar(
        //     radius: 50,
        //     backgroundColor: Colors.red,
        //     backgroundImage:
        //         AssetImage('assets/Screenshot 2024-02-21 133722.png'),
        //   ),
        //   SizedBox(
        //     //المقاس بمزاجي
        //     height: 20,
        //   ),

        //   CircleAvatar(
        //     radius: 50,
        //     backgroundColor: Colors.black,
        //     backgroundImage:
        //         AssetImage('assets/Screenshot 2024-02-21 133722.png'),
        //   ),

        //   Spacer(
        //     flex: 10,
        //   )
        //]),
        //
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Center(),
            CircleAvatar(
              radius: 85,
              backgroundColor: Colors.lightBlue,
              child: CircleAvatar(
                backgroundImage: NetworkImage(
                    'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAflBMVEX///9fyfhax/gxufYHW50EWZwDWJxPxfjz+/4IXJ5hhrSi3ftVxvjd5e4AVJrX8P3n9v5HvveG0/nN7P0AT5jf8/140PkATJcARpTS7v245fvE6Py2xtro9v4tqucMs/UARJNOrOAIO4uW2fotu/au3/oGOYnC4PNSfK7v8/fVukePAAADUklEQVR4nO3c21LbMBSFYSuxJVJSUVqDTaEmoS1t3/8F6wNxEluytzvTyd6b9Q+XXPibJaIhHJIEIYQQQgghhBBCCCGEEEIIIYQQQggp6eZ6Qd+vLv24y3twW2rOuZtLP+7yHpwJtQqmCBgWagIGhaqAIaFE4E0UGBAqA46F2oAjoTrgUKgPaOQD46+iAaFGoFEPNOqBRj3QqAca9UCjHmgAZBsRaNQDjXqgUQ806oEGQI4BCCDzvgAIIO8ABJB5AALIPADfE9C4u0s/7vKWAdUvqB6II8ovLAgg8wAEkHkAAsg8AAFkHoAAMg9AAJkHIIDMAxDAuqtFCQTeO3q395yBnyLA7egv8aK5zwAC+L+AK4nAO+3AJPlK/7V0mUA6USyQShQMpBFFAylE4cB5onjgHFEBcJqoAjhFVAKME9UAY8SV+xb+dHnAMDG64K2L/BMoxsAQMQ5cr7dUIh/gmBg9ojWQTOQEHBKnFiQTeQHPiXNAEpEb8JQ4fUSJRH7AI3F+wZYoD3gg0oAzRJ7Ajkg5ol1OHrAhUhecJPIFNkQ6MErkDEySyA9OgsAIkTcwUgQYJOoCBojagCOiPuCAKBK4mgaeEUUC72cmPCXKBG7nhQeiUKAhCDuiUOBqRRE2RLFAmnDtRAJN+w0STbiWCEweHV1Y+Y+Xftx/qSWShFWW5WKJFGGVpRu5RIKwsulmI5c4L+yAcok/qECxxJ/PM0CfHYRSideTxMrb7EBMU6uP2ADfiGmTOmKVe9sSsw6YpsoOag30B2KqkVgV3rdEq5RYlXneEX1r7ImFEmIDjBBlrji8F6uyyHui9z2vfUWVueI5sdoVnbA1nvnqr0mhxMfj+4Zm/1IUb0Rv03QArIkyD2pPrIFl0Zb7/iY88Ylf0exfy7KoP4a8I1A2sVmw5uXZZug7AUo+qO2CuR3zznySV9y/BnkjoFjir5c0xBv75BKfdjSg4HvxqSQNKHrFctYn/V48J0YHVEKc2E8FMbSaknvxqczmzqcCImXABmh1EUNAscQdYcAOKJY4v6LtU0q0VjyxP6gTB9R2b6hKJZY25hsABRMjvhEwy7xQ4s6Ty3cyiR8W9PvPpR8XIYQQQgghhBBCCCGEEEIIIYQQQui99xd9MndVczNj5wAAAABJRU5ErkJggg=='),
                radius: 80,
              ),
            ),
            Text(
              "Information",
              style: TextStyle(
                  fontSize: 50,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
            ),
            Divider(color: Colors.white),
            SizedBox(
              height: 2,
            ),
            Container(
              width: 300,
              height: 40,
              color: Colors.white,
              child: Row(
                children: [
                  Icon(
                    Icons.telegram,
                    size: 30,
                  ),
                  Text("                   "),
                  Text(
                    "010000000000",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              width: 300,
              height: 40,
              color: Colors.white,
              child: Row(
                children: [
                  Icon(
                    Icons.mail,
                    size: 30,
                  ),
                  Text("       "),
                  Text(
                    " 0000000000@mail.com",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
