package com.example.sa11

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
